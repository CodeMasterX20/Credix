#include <iostream>
#include <thread>
#include <chrono>
#include <string>
using namespace std;

int option;
int comp;
int indi;
string paycomp;
string payindi;
int money = 5000;
    
int payc1;
int payc2;
int payc3;
int payc4;
int payc5;
int payc6;
int payc7;
int payc8;
int payc9;
int payc10;
    
char c;
char payment;

void Clear() {
    for (int i = 0; i < 100; i++) {
        cout << endl;
    }
}

void showmain(); 

void individual() {
    Clear();
    cout << "From 1-5000$, how much do you want to pay?" << endl;
    cin.ignore();
    getline(cin, payindi);
    int amount = stoi(payindi);
    
    if (money >= amount) {
        money -= amount;
        cout << endl << "Payment successful to individual #" << indi << "." << endl;
        cout << "You have $" << money << " left." << endl;
        cout << "...Redirecting to main page..." << endl;
        this_thread::sleep_for(chrono::seconds(5));
        showmain();
    } else {
        cout << endl << "Uh oh! you don't have enough money! Payment not successful to individual #" << indi << "." << endl;
        cout << "You have $" << money << " left." << endl;
        cout << "...Redirecting to main page..." << endl;
        this_thread::sleep_for(chrono::seconds(5));
        showmain();
    }
}

void company() {
    Clear();
    cout << "From 1-5000$, how much do you want to pay?" << endl;
    cin.ignore();
    getline(cin, paycomp);
    int amount = stoi(paycomp);
    
    if (money >= amount) {
        money -= amount;
        cout << endl << "Payment successful to company #" << comp << "." << endl;
        cout << "You have $" << money << " left." << endl;
        cout << "...Redirecting to main page..." << endl;
        this_thread::sleep_for(chrono::seconds(5));
        showmain();
    } else {
        cout << endl << "Uh oh! you don't have enough money! Payment not successful to company #" << comp << "." << endl;
        cout << "You have $" << money << " left." << endl;
        cout << "...Redirecting to main page..." << endl;
        this_thread::sleep_for(chrono::seconds(5));
        showmain();
    }
}

void one() {
    Clear();
        
    cout << "Would you like to do payment to comp or individual?" << endl;
    cout << "(c for comp and i for individual)" << endl;
    cin >> payment;
        
    if (payment == 'c') {
        Clear();
            
        cout << "Which comp?" << endl;
        cout << "1 - Google" << endl;
        cout << "2 - ChatGPT" << endl;
        cout << "3 - Apple" << endl;
        cout << "4 - Android" << endl;
        cout << "5 - Microsoft" << endl;
        cout << "6 - Meta" << endl;
        cout << "7 - Tesla" << endl;
        cout << "8 - Facebook" << endl;
        cout << "9 - Amazon" << endl;
        cout << "10 - YouTube" << endl;
        
        cin >> comp;
        company();
    } else if (payment == 'i') {
        Clear();
        
        cout << "Which individual?" << endl;
        cout << "1 - Elon Musk" << endl;
        cout << "2 - Mark Zuckerberg" << endl;
        cout << "3 - Jeff Bezos" << endl;
        cout << "4 - Larry Ellison" << endl;
        cout << "5 - Bernard Arnault" << endl;
        cout << "6 - Warren Buffet" << endl;
        cout << "7 - Larry Page" << endl;
        cout << "8 - Sergrey Brin" << endl;
        cout << "9 - Steve Ballmer" << endl;
        cout << "10 - Jensen Huang" << endl;
        
        cin >> indi;
        individual();
    }
}

void refund(int amount) {
    cout << "The government owes you $" << amount << endl;
    money += amount;
    cout << "You have $" << money << " left." << endl;
    cout << "...Redirecting to main page..." << endl;
    this_thread::sleep_for(chrono::seconds(3));
    showmain();
}

void owe(int amount) {
    cout << "You owe the government $" << amount << endl;
    money -= amount;
    if (money < 0) {
        cout << "Be careful! You're in debt!" << endl;
    }
    cout << "You have $" << money << " left." << endl;
    cout << "...Redirecting to main page..." << endl;
    this_thread::sleep_for(chrono::seconds(3));
    showmain();
} 

void two() {
    Clear();
    
    int chance = rand() % 100 + 1;
    int mrefund = rand() % 450 + 1;
    int mowe = rand() % 2500 + 1;
    
    if (chance <= 90) {
        refund(mrefund);
    } else {
        owe(mowe);
    }
}

void three() {
    Clear();
    
    cout << "Amount of money:" << endl;
    cout << money << endl;
    
    int chance = rand() % 100 + 1;
    int mrefund = rand() % 450 + 1;
    int mowe = rand() % 2500 + 1;

    if (chance <= 50) {
        cout << endl;
        cout << "Amount of debt:" << endl;
        cout << "0" << endl;
        cout << "Amount of refunds from the government:" << endl;
        cout << mrefund << endl;
        money += mrefund;
    } else if (chance <= 75) {
        cout << endl;
        cout << "Amount of debt:" << endl;
        cout << mowe << endl;
        cout << "Amount of refunds from the government:" << endl;
        cout << "0" << endl;
        money -= mowe;
    } else { 
        cout << endl;
        cout << "Amount of debt:" << endl;
        cout << mowe << endl;
        cout << "Amount of refunds from the government:" << endl;
        cout << mrefund << endl;
        money -= mowe;
        money += mrefund;
    }
    
    cout << endl;
    
    if (money < 0) {
        cout << "Be careful! You're in debt!" << endl;
    }
    
    cout << "You have $" << money << " left." << endl;
    cout << "...Redirecting to main page..." << endl;
    this_thread::sleep_for(chrono::seconds(3));
    showmain();
}

void four() {
    Clear();
    
    cout << "How much would you like to loan? (1-5000$)" << endl;
    int loan;
    cin >> loan;
    
    if (loan > 0 && loan <= 5000) {
        money += loan;
        cout << "Loan approved! $" << loan << " has been added to your account." << endl;
        cout << "You now have $" << money << " total." << endl;
    } else {
        cout << "Invalid loan amount." << endl;
    }
    
    cout << "...Redirecting to main page..." << endl;
    this_thread::sleep_for(chrono::seconds(3));
    showmain();
}

void five() {
    Clear();
    
    cout << "How much would you like to donate to charity? (1–5000$)" << endl;
    int donate;
    cin >> donate;
    
    if (donate > 0 && donate <= 5000) {
        Clear();
        
        money -= donate;
        cout << "Thank you for your generosity! You donated $" << donate << " to charity." << endl;

        int bonusChance = rand() % 100 + 1;
        if (bonusChance <= 50) {
            int bonus = rand() % 200 + 50;
            money += bonus;
            cout << "Bonus! The government rewarded your kindness with $" << bonus << "!" << endl;
        }
    } else {
        Clear();
        cout << "Invalid number." << endl;
    }
    
    Clear();
    
    cout << "You have $" << money << " left." << endl;
    cout << "...Redirecting to main page..." << endl;
    this_thread::sleep_for(chrono::seconds(3));
    showmain();
}


void showmain() {
    Clear();
    
    cout << "Menu: " << endl;
    cout << "1 - Make payment." << endl;
    cout << "2 - Pay taxes or get refunds." << endl;
    cout << "3 - See bank account." << endl;
    cout << "4 - Take a loan." << endl;
    cout << "5 - Donate to charity." << endl;
    cout << endl;
    cin >> option;
    if (option == 1) {
        one();
    } else if (option == 2) {
        two(); 
    } else if (option == 3) {
        three();
    } else if (option == 4) {
        four();
    } else if (option == 5) {
        five();
    } else {
        Clear();
        cout << "Invalid option." << endl;
        cout << "You have $" << money << " left." << endl;
        cout << "...Redirecting to main page..." << endl;
        this_thread::sleep_for(chrono::seconds(3));
        showmain();
    }
}

void loadup() {
    Clear();
    cout << "Loading Credix Banking System" << endl;
    cout << "[=         ] 10%" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Loading Credix Banking System" << endl;
    cout << "[===       ] 30%" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Loading Credix Banking System" << endl;
    cout << "[=====     ] 50%" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Loading Credix Banking System" << endl;
    cout << "[=======   ] 70%" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Loading Credix Banking System" << endl;
    cout << "[========= ] 90%" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Loading Credix Banking System" << endl;
    cout << "[==========] 100%" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Startup complete. Launching system" << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Startup complete. Launching system." << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Startup complete. Launching system.." << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Startup complete. Launching system..." << endl;
    this_thread::sleep_for(chrono::milliseconds(500));
    Clear();
    cout << "Startup complete. Launching system..." << endl;
    this_thread::sleep_for(chrono::seconds(2));
}

int main() {
    srand(time(0));
    
    cout << "Hello! Welcome to the banking system/website called Credix." << endl;
    cout << "We offer quick and swift payment methods whether for when you're on the go, or doing your taxes," << endl;
    cout << "You can count on us." << endl;
    cout << "Yours truly, Credix." << endl;
    cout << "(Say c to continue, anything else quit.)" << endl;
    cout << endl;
    cin >> c;
    
    if (c == 'c') {
        loadup();
        Clear();
        showmain();
    } else {
        cout << "Goodbye!" << endl;
    }
    
    return 0;
}
